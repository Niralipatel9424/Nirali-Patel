// Function to get current date and time
function getCurrentDateTime() {
    const now = new Date();
    const dateString = now.toLocaleDateString();
    const timeString = now.toLocaleTimeString();
    return `Current date: ${dateString}, Current time: ${timeString}`;
}

// Function to show an alert
function showAlert() {
    alert("This is an alert!");
}

// Using a Math method
const randomNumber = Math.random();

// Delaying a command
setTimeout(() => {
    console.log("Delayed command executed.");
}, 3000); // 3 seconds delay

// Countdown function
function countdown(seconds) {
    let timer = seconds;
    const countdownInterval = setInterval(() => {
        if (timer <= 0) {
            clearInterval(countdownInterval);
            console.log("Countdown complete!");
        } else {
            console.log(`${timer} seconds remaining...`);
            timer--;
        }
    }, 1000); // Update every second
}

// Example usage
console.log(getCurrentDateTime());
showAlert();
console.log("Random number:", randomNumber);
countdown(5); // Countdown from 5 seconds

// Creating a link for downloading 
            // Excel sheet 
            const link = 
                document.createElement( 
                    "a"
                ); 
            link.href = 
                window.URL.createObjectURL( 
                    blob 
                ); 
            link.download = 
                "FeedBack.csv"; 
            link.click(); 